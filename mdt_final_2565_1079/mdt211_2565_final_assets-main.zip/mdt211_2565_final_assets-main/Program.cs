﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("You may use any class in this project for the final examination.");
    }
}